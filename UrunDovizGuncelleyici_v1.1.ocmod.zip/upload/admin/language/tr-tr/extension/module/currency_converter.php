<?php
// Heading
$_['heading_title']    = 'Para Birimi Dönüştürücü';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Para Birimi Dönüştürücü ayarları güncellendi!';
$_['text_edit']        = 'Para Birimi Dönüştürücü Düzenle';

// Entry
$_['entry_status']     = 'Durum';

// Error
$_['error_permission'] = 'Uyarı: Para Birimi Dönüştürücü modülünü düzenleme iznine sahip değilsiniz!';

// Remove these lines to prevent heading_title from appearing multiple times
$_['heading_title_1']  = '';
$_['heading_title_2']  = '';
$_['heading_title_3']  = ''; 